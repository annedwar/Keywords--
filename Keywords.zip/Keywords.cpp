// Keywords.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
	enum fields { WORD, HINT, NUM_FIELDS };
	const int NUM_WORDS = 3;
	const string WORDS[NUM_WORDS][NUM_FIELDS] =
	{
		{"food", "Substance that keeps you alive."},
		{"seven", "A number between 1 and 10."},
		{"computer", "You need this to write programs on."},
		{"cloud", "Something in the sky."},
		{"headphones", "You use these to listen quietly."},
		{"trick", "This or treat."},
		{"restaurant", "People go here to eat."},
		{"ramen", "A popular asian noodle."},
		{"breakfast", "Morning food."},
		{"hint", "What you're using right now, you noob."}
	};

	srand(static_cast<unsigned int>(time(0)));
	int choice = (rand() % NUM_WORDS);
	string theWord = WORDS[choice][WORD]; //word to guess
	string theHint = WORDS[choice][HINT]; //hint for word

	string jumble = theWord; //jumbling the word 
	int length = jumble.size();
	for (int i = 0; i < length; ++i)
	{
		int index1 = (rand() % length);
		int index2 = (rand() % length);
		char temp = jumble[index1];
		jumble[index1] = jumble[index2];
		jumble[index2] = temp;
	}

	cout << "\t\t\Welcome to your code breaking simulation program!\n\n";
	cout << "Unscramble the letters to make a word. \n";
	cout << "Enter 'hint' for a hint. \n";
	cout << "Enter 'quit' to quit. \n";
	cout << "The jumbled word is: " << jumble;

	string guess;
	cout << "\n\nYour guess: ";
	cin >> guess;

	while ((guess != theWord) && (guess != "quit"))
	{
		if (guess == "hint")
		{
			cout << theHint;
		}
		else
		{
			cout << "That is not the correct answer.";
		}
		cout << "\n\nYour guess: ";
		cin >> guess;
	}

	if (guess == theWord)
	{
		cout << "\nThat is correct.\n";
	}

	cout << "\nCode breaking simulation, complete.\n";

    return 0;
}


